import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * The Car class represents a car object with make, year, and price attributes.
 * This class implements Comparable interface to enable sorting based on car attributes.
 * CSC 1351 Programming Project No 1
 * Section 1
 *
 * @author Ahmed Hatem
 * @since 3/17/2024
 */
class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    /**
     * Constructs a new Car instance with specified make, year, and price.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @param make The make of the car
     * @param year The year of manufacture of the car
     * @param price The price of the car
     */

    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }

    public String getMake() {
        return make;
    }

    public int getYear() {
        return year;
    }

    public int getPrice() {
        return price;
    }


    @Override
    public int compareTo(Car other) {
        // First, compare the make
        int makeComparison = this.make.compareTo(other.make);
        if (makeComparison != 0) {
            return makeComparison;
        }
        // If makes are the same, compare the year
        return Integer.compare(this.year, other.year);
    }

    @Override
    public String toString() {
        return "Make: " + make + "\nYear: " + year + "\nPrice: " + price + "\n";
    }
}

/**
 * The Prog01_aOrderedList class manages a list of Car objects in a specified order.
 * It provides functionalities to read Car data from an input file, process it,
 * and write the ordered list of Cars to an output file.
 * CSC 1351 Programming Project No 1
 * Section 1
 *
 * @author Ahmed Hatem
 * @since 03/17/2024
 */

public class Prog01_aOrderedList {
    static aOrderedList orderedList = new aOrderedList();
    public static void main(String[] args) {
        try {
            Scanner fileScanner = getInputFile("Enter input filename: ");
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(",");
                String operation = parts[0].trim();

                if ("A".equals(operation)) {
                    // Add
                    Car car = new Car(parts[1].trim(), Integer.parseInt(parts[2].trim()), Integer.parseInt(parts[3].trim()));
                    orderedList.add(car);
                } else if ("D".equals(operation)) {
                    // Delete
                    String make = parts[1].trim();
                    int year = Integer.parseInt(parts[2].trim());
                    deleteCarByMakeAndYear(orderedList, make, year);
                }
            }
            fileScanner.close();


            PrintWriter outputWriter = getOutputFile("Enter output filename: ");
            outputWriter.println("Number of Cars: " + orderedList.size());
            outputWriter.println(orderedList);
            outputWriter.close();
        } catch (FileNotFoundException e) {
            System.out.println("Program Cancelled.");
        }

    }

    /**
     * Prompts the user for an input filename and returns a Scanner object for that file.
     * The method continues to prompt until a valid file is provided or the user decides to exit.
     * If the file does not exist, the user is given the option to enter a different file name or cancel the operation.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     **/

    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        Scanner console = new Scanner(System.in);
        while (true) {
            System.out.print(userPrompt);
            String filename = console.nextLine();
            File file = new File(filename);

            if (file.exists()) {
                return new Scanner(file);
            } else {
                System.out.print("File specified <" + filename + "> does not exist. Would you like to continue? <Y/N> ");
                String response = console.nextLine();
                if (response.equalsIgnoreCase("N")) {
                    throw new FileNotFoundException();
                }
            }
        }
    }

    /**
     * Processes a line from the input file and performs operations on the ordered list
     * based on the instructions in the line. The line can contain instructions to add or delete
     * a Car object from the list.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     */
    public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner console = new Scanner(System.in);
        while (true) {
            System.out.print(userPrompt);
            String filename = console.nextLine();
            try {
                return new PrintWriter(filename);
            } catch (FileNotFoundException e) {
                System.out.print("File specified <" + filename + "> cannot be used. Would you like to continue? <Y/N> ");
                String response = console.nextLine();
                if (response.equalsIgnoreCase("N")) {
                    throw e;
                }
            }
        }
    }

    /**
     * Deletes a Car from the ordered list based on its make and year.
     * This method iterates through the list, finds the first car that matches
     * the specified make and year, and removes it from the list.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     **/
    private static void deleteCarByMakeAndYear(aOrderedList orderedList, String make, int year) {
        for (int i = 0; i < orderedList.size(); i++) {
            Car car = (Car) orderedList.get(i);
            if (car.getMake().equals(make) && car.getYear() == year) {
                orderedList.remove(i);
                return;
            }
        }
    }

}
/**
 * The aOrderedList class implements an ordered list of Comparable objects.
 * It maintains objects in sorted order and provides functionalities for adding,
 * removing, and accessing elements. The sorting is based on the natural ordering
 * of the elements (defined by their compareTo method).
 * CSC 1351 Programming Project No 1
 * Section 1
 *
 * @author Ahmed Hatem
 * @since 3/17/2024
 */
class aOrderedList {
    private final int SIZEINCREMENTS = 20;
    private Comparable[] oList;
    private int listSize;
    private int numObjects;
    private int curr; // Iterator index


    /**
     * Constructs an empty aOrderedList with an initial capacity.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     */
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[SIZEINCREMENTS];
    }

    /**
     * Adds a new Car object to the ordered list. The list is re-arranged to maintain order.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @param newCar The Car object to be added
     */
    public void add(Car newCar) {
        if (numObjects >= listSize) {
            increaseListSize();
        }
        int i;
        for (i = numObjects - 1; (i >= 0 && newCar.compareTo((Car) oList[i]) < 0); i--) {
            oList[i + 1] = oList[i];
        }
        oList[i + 1] = newCar;
        numObjects++;
    }

    /**
     * Increases the size of the list when it reaches its capacity. The new size is double the current size.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     */
    private void increaseListSize() {
        oList = Arrays.copyOf(oList, 2 * oList.length);
        listSize = oList.length;
    }


    /**
     * Returns a string representation of the objects in the ordered list.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @return String representation of the list
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < numObjects; i++) {
            sb.append(oList[i].toString());
            if (i < numObjects - 1) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    /**
     * Returns the number of objects currently in the list.
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @return The number of objects in the list
     */
    public int size() {
        return numObjects;
    }

    /**
     * Retrieves the object at the specified index in the list.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @param index The index of the object to retrieve
     * @return The object at the specified index
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    public Car get(int index) {
        if (index >= 0 && index < numObjects) {
            return (Car) oList[index];
        } else {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        }
    }
    /**
     * Checks if the list is empty.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @return true if the list is empty, false otherwise
     */
    public boolean isEmpty() {
        return numObjects == 0;
    }

    //resets, simple.
    public void reset() {
        curr = 0;
    }

    /**
     * Returns the next object in the list and advances the iterator.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @return The next object in the list
     * @throws NoSuchElementException if there is no next element
     */
    public Comparable next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        return oList[curr++];
    }
//Checks if there is a next element in the list.
    public boolean hasNext() {
        return curr < numObjects;
    }
    /**
     * Removes the last object returned by the iterator from the list.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @throws IllegalStateException if the remove operation is not valid at the current state
     */
    public void remove() {
        if (curr == 0) {
            throw new IllegalStateException();
        }
        aOrderedList.this.remove(curr - 1);
    }
    /**
     * Removes the object at the specified index from the list.

     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Ahmed Hatem
     * @since 3/17/2024
     *
     * @param index The index of the object to remove
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    public void remove(int index) {
        if (index >= 0 && index < numObjects) {
            for (int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            oList[numObjects - 1] = null; // Clear the last element
            numObjects--;
        } else {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        }
    }
}
